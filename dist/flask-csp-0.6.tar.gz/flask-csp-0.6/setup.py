from setuptools import setup, find_packages

setup(
  name = 'flask-csp',
  packages = find_packages(exclude=['tests*']),
  py_modules = ['flask_csp'],
  version = '0.6',
  description = 'Flask Content Security Policy header support',
  license='MIT',
  author = 'Tristan Waldear',
  author_email = 'trwaldear@gmail.com',
  url = 'https://github.com/twaldear/flask-csp',
  download_url = 'https://github.com/twaldear/flask-csp/tarball/0.1',
  keywords = ['flask', 'csp', 'header'],
  classifiers=[
    'Programming Language :: Python',
    'Operating System :: OS Independent',
    'Topic :: Software Development :: Libraries :: Python Modules',
  ]
)